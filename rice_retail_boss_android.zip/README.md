# Rice Retail Boss - Android-only (scaffold)

This is a minimal Flutter scaffold for the Rice Retail Boss app (Android only).  
It includes a simple local database (sqflite) to manage products, sales, and expenses.

## Quick start (on your PC with Flutter installed)

1. Unzip the project and `cd` into the folder.
2. Run:
   ```bash
   flutter create .
   flutter pub get
   flutter run   # for debug on connected device
   # or
   flutter build apk --release
   ```
3. The app uses local SQLite (sqflite). No remote backend included in this scaffold.
4. To enable payments/subscriptions (GCash/PayMongo) and admin dashboard, we can add them later.

If you want, I can:
- Upload this to your GitHub repo,
- Set up GitHub Actions to build the APK automatically,
- Or build the APK for you if you provide a way to accept the generated file.

