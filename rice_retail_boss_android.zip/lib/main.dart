import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'src/db.dart';
import 'src/models.dart';
import 'src/screens/home.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final db = await AppDatabase.open();
  runApp(MyApp(db: db));
}

class MyApp extends StatelessWidget {
  final AppDatabase db;
  const MyApp({required this.db, super.key});

  @override
  Widget build(BuildContext context) {
    return Provider<AppDatabase>.value(
      value: db,
      child: MaterialApp(
        title: 'Rice Retail Boss',
        theme: ThemeData(primarySwatch: Colors.green),
        home: const HomeScreen(),
      ),
    );
  }
}
