import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'models.dart';

class AppDatabase {
  final Database db;
  AppDatabase(this.db);

  static Future<AppDatabase> open() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, 'rice_retail_boss.db');
    final database = await openDatabase(path, version: 1, onCreate: (db, version) async {
      await db.execute('''
        CREATE TABLE products(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT,
          stock INTEGER
        )
      ''');
      await db.execute('''
        CREATE TABLE sales(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          product_id INTEGER,
          quantity INTEGER,
          total INTEGER,
          created_at TEXT
        )
      ''');
      await db.execute('''
        CREATE TABLE expenses(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          description TEXT,
          amount INTEGER,
          created_at TEXT
        )
      ''');
    });
    return AppDatabase(database);
  }

  Future<int> insertProduct(Product p) =>
      db.insert('products', p.toMap());

  Future<List<Product>> allProducts() async {
    final rows = await db.query('products', orderBy: 'id DESC');
    return rows.map((r) => Product.fromMap(r)).toList();
  }

  Future<int> insertSale(Sale s) =>
      db.insert('sales', s.toMap());

  Future<int> insertExpense(Expense e) =>
      db.insert('expenses', e.toMap());

  Future<List<Sale>> allSales() async {
    final rows = await db.query('sales', orderBy: 'id DESC');
    return rows.map((r) => Sale.fromMap(r)).toList();
  }

  Future<List<Expense>> allExpenses() async {
    final rows = await db.query('expenses', orderBy: 'id DESC');
    return rows.map((r) => Expense.fromMap(r)).toList();
  }

  Future<void> updateProductStock(int id, int newStock) async {
    await db.update('products', {'stock': newStock}, where: 'id = ?', whereArgs: [id]);
  }
}
