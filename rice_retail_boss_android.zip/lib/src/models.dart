class Product {
  final int? id;
  final String name;
  final int stock;
  Product({this.id, required this.name, required this.stock});
  Map<String, Object?> toMap() => {'id': id, 'name': name, 'stock': stock};
  static Product fromMap(Map<String, Object?> m) => Product(id: m['id'] as int?, name: m['name'] as String, stock: m['stock'] as int);
}

class Sale {
  final int? id;
  final int productId;
  final int quantity;
  final int total;
  final String createdAt;
  Sale({this.id, required this.productId, required this.quantity, required this.total, required this.createdAt});
  Map<String, Object?> toMap() => {'id': id, 'product_id': productId, 'quantity': quantity, 'total': total, 'created_at': createdAt};
  static Sale fromMap(Map<String, Object?> m) => Sale(id: m['id'] as int?, productId: m['product_id'] as int, quantity: m['quantity'] as int, total: m['total'] as int, createdAt: m['created_at'] as String);
}

class Expense {
  final int? id;
  final String description;
  final int amount;
  final String createdAt;
  Expense({this.id, required this.description, required this.amount, required this.createdAt});
  Map<String, Object?> toMap() => {'id': id, 'description': description, 'amount': amount, 'created_at': createdAt};
  static Expense fromMap(Map<String, Object?> m) => Expense(id: m['id'] as int?, description: m['description'] as String, amount: m['amount'] as int, createdAt: m['created_at'] as String);
}
