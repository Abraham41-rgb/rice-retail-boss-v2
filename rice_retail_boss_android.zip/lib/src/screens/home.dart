import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../src/db.dart';
import '../../src/models.dart';
import 'package:intl/intl.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late AppDatabase db;
  List<Product> products = [];
  List<Sale> sales = [];
  List<Expense> expenses = [];
  final _productNameCtrl = TextEditingController();
  final _stockCtrl = TextEditingController();
  final _expenseDesc = TextEditingController();
  final _expenseAmt = TextEditingController();

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    db = Provider.of<AppDatabase>(context);
    _loadAll();
  }

  Future<void> _loadAll() async {
    products = await db.allProducts();
    sales = await db.allSales();
    expenses = await db.allExpenses();
    setState((){});
  }

  Future<void> _addProduct() async {
    final name = _productNameCtrl.text.trim();
    final stock = int.tryParse(_stockCtrl.text) ?? 0;
    if (name.isEmpty) return;
    await db.insertProduct(Product(name: name, stock: stock));
    _productNameCtrl.clear();
    _stockCtrl.clear();
    await _loadAll();
  }

  Future<void> _recordSale(Product p) async {
    if (p.stock <= 0) return;
    await db.insertSale(Sale(productId: p.id!, quantity: 1, total: 0, createdAt: DateTime.now().toIso8601String()));
    await db.updateProductStock(p.id!, p.stock - 1);
    await _loadAll();
  }

  Future<void> _addExpense() async {
    final desc = _expenseDesc.text.trim();
    final amt = int.tryParse(_expenseAmt.text) ?? 0;
    if (desc.isEmpty) return;
    await db.insertExpense(Expense(description: desc, amount: amt, createdAt: DateTime.now().toIso8601String()));
    _expenseDesc.clear();
    _expenseAmt.clear();
    await _loadAll();
  }

  @override
  Widget build(BuildContext context) {
    final df = DateFormat('yyyy-MM-dd HH:mm');
    return Scaffold(
      appBar: AppBar(title: const Text('Rice Retail Boss')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Products', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            Row(children: [
              Expanded(child: TextField(controller: _productNameCtrl, decoration: const InputDecoration(hintText: 'Product name'))),
              const SizedBox(width:8),
              SizedBox(width:100, child: TextField(controller: _stockCtrl, decoration: const InputDecoration(hintText: 'Stock'), keyboardType: TextInputType.number)),
              const SizedBox(width:8),
              ElevatedButton(onPressed: _addProduct, child: const Text('Add'))
            ]),
            const SizedBox(height:12),
            if (products.isEmpty) const Text('No products yet'),
            for (var p in products) ListTile(
              title: Text(p.name),
              subtitle: Text('Stock: ${p.stock}'),
              trailing: ElevatedButton(onPressed: () => _recordSale(p), child: const Text('Sell')),
            ),
            const Divider(),
            const Text('Expenses', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            Row(children:[
              Expanded(child: TextField(controller: _expenseDesc, decoration: const InputDecoration(hintText: 'Description'))),
              const SizedBox(width:8),
              SizedBox(width:120, child: TextField(controller: _expenseAmt, decoration: const InputDecoration(hintText: 'Amount'), keyboardType: TextInputType.number)),
              const SizedBox(width:8),
              ElevatedButton(onPressed: _addExpense, child: const Text('Add'))
            ]),
            const SizedBox(height:12),
            if (expenses.isEmpty) const Text('No expenses yet'),
            for (var e in expenses) ListTile(title: Text(e.description), subtitle: Text('₱${e.amount} • ${df.format(DateTime.parse(e.createdAt))}')),
            const Divider(),
            const Text('Sales (recent)', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            if (sales.isEmpty) const Text('No sales yet'),
            for (var s in sales) ListTile(title: Text('Product ID: ${s.productId}'), subtitle: Text('${s.quantity} pcs • ${df.format(DateTime.parse(s.createdAt))}')),
            const SizedBox(height: 40)
          ],
        ),
      ),
    );
  }
}
